package com.percussion.pso.rssimport;

import com.percussion.cms.PSCmsException;
import com.percussion.cms.objectstore.PSCoreItem;
import com.percussion.cms.objectstore.PSItemDefinition;

public class PSORSSItem extends PSCoreItem {
	//This class is implemented to allow import extensions to be backwards compatible with the new
	//interface
	public PSORSSItem(PSItemDefinition arg0) throws PSCmsException {
		super(arg0);
	
	}

}

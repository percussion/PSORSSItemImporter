package com.percussion.pso.rssimport;

import java.util.HashMap;
import java.util.Map;

public class PSORSSImportExtensionCall {

	private String className;
	private Map paramMap = new HashMap();
	
	public PSORSSImportExtensionCall(String name) {
		this.className=name;
	}

	public String getClassName() {
		return className;
	}

	public Map getParamMap() {
		return paramMap;
	}

	public void setParam(String name, String value) {
		paramMap.put(name, value);
	}

}
